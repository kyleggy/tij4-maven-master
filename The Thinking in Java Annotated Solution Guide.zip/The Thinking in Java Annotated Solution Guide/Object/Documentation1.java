// object.Documentation1.java
// TIJ4 Chapter Object, Exercise 13 - 1
/* Run Documentation1.java, Documentation2.java and Documentation3.java 
* through Javadoc. Verify the resulting documentation with your Web browser. 
*/

/** A class comment */
public class Documentation1 {
	/** A field comment */
	public int i;
	/** A method comment */
	public void f() {}
}



